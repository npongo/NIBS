"""
nibs_helper_gpt.py — NIBS India cropland GHG helper, adapted for ChatGPT's
Code Interpreter / Data Analysis sandbox.

Key difference from the Claude-skill version (nibs_helper.py): ChatGPT's code
sandbox has no outbound internet access, so this version can't download
parquet files itself. Instead it:
  - uses nib_urls.json purely as a lookup so the assistant can TELL the user
    which Dropbox URL to fetch and upload into the chat, and
  - reads/queries whatever parquet file(s) the user has actually uploaded
    into the conversation (ChatGPT places uploaded files on local disk,
    typically under /mnt/data/).

I (the assistant preparing this file) could not verify exactly which Python
packages ship in your ChatGPT Code Interpreter environment, so this tries a
few options for reading parquet and querying it, in order of preference, and
tells you clearly which one it ended up using. If none of them import, ask
the assistant to try `!pip install duckdb` or `!pip install pyarrow` in the
session first — that sometimes works even offline if the wheel is bundled,
sometimes doesn't.

Usage inside a ChatGPT Code Interpreter cell:

    from nibs_helper_gpt import NIBS
    nibs = NIBS(data_dir="/mnt/data")   # wherever your uploaded files land
    nibs.search("nikolaisen")           # find candidate dataset names
    nibs.get_url("vwM_district_ch4_summary_nikolaisen_2023")  # tells you what to upload
    df = nibs.load_local("vwM_district_ch4_summary_nikolaisen_2023")  # once uploaded
"""
from __future__ import annotations

import glob
import json
import os
from typing import Optional

import pandas as pd

_HERE = os.path.dirname(__file__)
_CATALOG_PATH = os.path.join(_HERE, "nib_urls.json")

# Figure out, once, which parquet engine is actually available in this sandbox.
_ENGINE = None
try:
    import duckdb  # noqa: F401

    _ENGINE = "duckdb"
except ImportError:
    try:
        import pyarrow  # noqa: F401

        _ENGINE = "pyarrow"
    except ImportError:
        try:
            import fastparquet  # noqa: F401

            _ENGINE = "fastparquet"
        except ImportError:
            _ENGINE = None


class NIBS:
    def __init__(self, data_dir: str = "/mnt/data", catalog_path: str = _CATALOG_PATH):
        self.data_dir = data_dir
        with open(catalog_path, encoding="utf-8") as f:
            self._urls: dict[str, str] = json.load(f)
        self._ci_keys = {k.lower(): k for k in self._urls}
        if _ENGINE is None:
            print(
                "WARNING: no parquet-capable package (duckdb / pyarrow / fastparquet) "
                "could be imported in this sandbox. Reading parquet files will fail "
                "until one is available. Try `!pip install pyarrow` in a cell."
            )
        else:
            print(f"nibs_helper_gpt: using '{_ENGINE}' to read parquet files.")

    # ------------------------------------------------------------------
    # catalog lookup (works offline, no file needed)
    # ------------------------------------------------------------------
    def resolve_key(self, name: str) -> str:
        base = os.path.basename(name)
        if base.lower().endswith(".parquet"):
            base = base[: -len(".parquet")]
        if base.lower() in self._ci_keys:
            return self._ci_keys[base.lower()]
        raise ValueError(
            f"Dataset '{name}' not found in the NIBS catalog. Use NIBS.search('{base}') "
            "to find close matches."
        )

    def get_url(self, name: str) -> str:
        """Return the Dropbox URL for a dataset — tell the user to download this
        and upload it into the chat, since this sandbox can't fetch it directly."""
        return self._urls[self.resolve_key(name)]

    def search(self, keyword: str) -> list[str]:
        kw = keyword.lower()
        return sorted(k for k in self._urls if kw in k.lower())

    def all_datasets(self) -> list[str]:
        return sorted(self._urls.keys())

    # ------------------------------------------------------------------
    # local file discovery + reading (needs the user to have uploaded the file)
    # ------------------------------------------------------------------
    def find_local(self, name: str) -> Optional[str]:
        """Look for an already-uploaded copy of this dataset under data_dir,
        matching on the dataset key regardless of exact filename casing/suffix."""
        key = self.resolve_key(name)
        candidates = glob.glob(os.path.join(self.data_dir, f"{key}*.parquet")) + glob.glob(
            os.path.join(self.data_dir, f"{key}*.PARQUET")
        )
        return candidates[0] if candidates else None

    def load_local(self, name: str) -> pd.DataFrame:
        """Load a dataset the user has already uploaded. Raises a clear error
        (with the Dropbox URL to fetch) if it hasn't been uploaded yet."""
        local_path = self.find_local(name)
        if local_path is None:
            key = self.resolve_key(name)
            raise FileNotFoundError(
                f"'{key}.parquet' isn't in {self.data_dir} yet. Download it from "
                f"{self._urls[key]} and upload it into this chat, then try again."
            )
        if _ENGINE is None:
            raise ImportError(
                "No parquet reader available in this sandbox (duckdb/pyarrow/"
                "fastparquet all failed to import) — can't load the file even "
                "though it's present."
            )
        return pd.read_parquet(local_path)  # pandas picks whichever engine is installed

    def query_local(self, sql: str) -> pd.DataFrame:
        """Run SQL against already-uploaded parquet file(s), referenced by short
        name inside read_parquet('name'). Requires duckdb specifically (pandas
        alone can't run arbitrary SQL) — falls back to telling you to filter
        with pandas/DataFrame.query() if duckdb isn't available."""
        if _ENGINE != "duckdb":
            raise ImportError(
                "query_local() needs duckdb specifically for SQL support, but it's "
                f"not available here (engine detected: {_ENGINE}). Use load_local() "
                "to get a plain DataFrame and filter it with pandas instead, e.g. "
                "df[(df['state'] == 'Haryana') & (df['gwp_time_period'] == 100)]."
            )
        import re

        import duckdb

        def repl(m):
            token = m.group(1)
            if os.path.exists(token):
                return m.group(0)
            local_path = self.find_local(token)
            if local_path is None:
                key = self.resolve_key(token)
                raise FileNotFoundError(
                    f"'{key}.parquet' isn't uploaded yet. Get it from "
                    f"{self._urls[key]} and upload it into this chat first."
                )
            return f"read_parquet('{local_path}')"

        local_sql = re.sub(r"read_parquet\(\s*'([^']+)'\s*\)", repl, sql, flags=re.IGNORECASE)
        con = duckdb.connect(database=":memory:")
        con.execute("SET default_collation = 'nocase';")
        df = con.execute(local_sql).fetch_df()
        con.close()
        return df

    def describe_local(self, name: str) -> pd.DataFrame:
        """Column schema for an already-uploaded dataset, without assuming column
        names in advance."""
        df = self.load_local(name)
        return pd.DataFrame({"column": df.columns, "dtype": [str(t) for t in df.dtypes]})
