# Setting this up as a Custom GPT

I (Claude) can't create or deploy this inside ChatGPT myself - I don't have
access to OpenAI's platform. These are the pieces to do it yourself; it
should take a few minutes.

## What's in this folder

- `instructions.md` - text to paste into the Custom GPT's "Instructions" field.
- `knowledge/dataset_catalog.md` - naming conventions and gas/model taxonomy.
- `knowledge/nib_urls.json` - all ~304 dataset names mapped to their Dropbox URLs.
- `knowledge/nibs_helper_gpt.py` - Python helper for Code Interpreter to use.

## Steps

1. In ChatGPT, go to **Explore GPTs -> Create** (or **My GPTs -> Create a GPT**),
   and use the "Configure" tab (skip the conversational builder).
2. Give it a name (e.g. "NIBS India Crop GHG") and a short description.
3. Paste the contents of `instructions.md` (everything below the `---` line)
   into the **Instructions** field.
4. Under **Knowledge**, upload all three files from the `knowledge/` folder:
   `dataset_catalog.md`, `nib_urls.json`, `nibs_helper_gpt.py`.
5. Under **Capabilities**, turn on **Code Interpreter & Data Analysis**. This
   is required - without it the GPT can't run Python/read parquet files at all.
6. Save/publish it (private to you, or shared, your choice).

## How it actually works day to day

Unlike the Claude skill version, this GPT **cannot download the parquet files
itself** - ChatGPT's Code Interpreter sandbox has no internet access, same
restriction we hit testing the Claude version in a locked-down sandbox, except
here it's permanent rather than environment-dependent. So the flow is:

1. Ask it your question (e.g. "CH4 per hectare for districts in Haryana,
   Nikolaisen model").
2. It'll tell you the exact dataset name and give you the Dropbox URL to
   download.
3. You download that one parquet file and upload it into the chat.
4. It reads the uploaded file with the bundled helper and gives you the real
   numbers, filtered and labeled correctly (model, GWP horizon, etc.).

This is more manual than the Claude skill (which can fetch files itself when
network access allows), but it's the only reliable pattern given Code
Interpreter's sandboxing - it doesn't get better with clever prompting.

## One thing I couldn't verify

I don't have a way to test what's actually pre-installed in ChatGPT's Code
Interpreter environment (duckdb, pyarrow, etc.) - I wrote `nibs_helper_gpt.py`
to auto-detect and fall back gracefully, and it printed a clear message about
which one it's using when I tested the logic here. If none of them import in
your GPT, ask it to try `!pip install pyarrow` in a code cell first - it
sometimes works offline from a bundled wheel cache, sometimes doesn't,
depending on OpenAI's current sandbox image. If that fails too, report back
and I can adjust the helper to lean on whatever's actually available.
