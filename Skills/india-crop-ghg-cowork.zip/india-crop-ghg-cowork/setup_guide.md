# Setting this up in Microsoft 365 Copilot Cowork

I can't place these files into your OneDrive myself - I don't have access to
your Microsoft 365 account. Here's how to do it (a few minutes).

## Interesting note before you start

Microsoft's Copilot Cowork is, per Microsoft's own documentation, built on
Anthropic Claude models for its reasoning and tool-use ("Cowork uses Anthropic
Claude models as a subprocessor for most reasoning, drafting, and
tool-using work"). So under the hood it's a close cousin of what wrote this
skill - the packaging format is different, but the underlying model
following the instructions is the same family.

## What's in this folder

- `SKILL.md` - the skill file itself, in Cowork's required format (YAML
  frontmatter with `name`/`description`, then Markdown instructions).
- `dataset_catalog.md` - naming conventions and gas/model taxonomy.
- `nib_urls.json` - all ~304 dataset names mapped to their Dropbox URLs.
- `nibs_helper.py` - an optional Python helper, untested in this environment
  (see the big caveat below).

## Steps

1. Go to your OneDrive and navigate to (or create) `/Documents/Cowork/skills/`.
2. Inside it, create a subfolder named `india-crop-ghg`.
3. Upload all four files from this folder into
   `/Documents/Cowork/skills/india-crop-ghg/`.
4. That's it - Cowork discovers custom skills automatically at the start of
   each new conversation. No install step, no admin panel.

Alternatively, you can skip the manual OneDrive upload and use Cowork's
**Customize** page (Skills tab -> Add -> Create new) to build the skill
conversationally - if you do that, paste the body of `SKILL.md` (everything
after the `---` frontmatter block) when it asks for instructions, and attach
`dataset_catalog.md` and `nib_urls.json` as reference files when prompted.

## The one real limitation here - bigger than the ChatGPT version

Two things compound to make this harder than the Claude-skill or even the
ChatGPT version:

1. **Cowork can't access local files at all** - only OneDrive/SharePoint
   content. The actual NIBS parquet files live on Dropbox, so there's no
   direct path from "Cowork wants the data" to "Cowork has the data" the way
   there might be with a locally-mounted drive.
2. **`.parquet` isn't in Microsoft's list of officially supported attachment
   types** for Cowork (Word/Excel/PowerPoint/PDF/Markdown/images/text/code/
   config/notebook/audio/video/archive are - parquet isn't mentioned).

So the realistic workflow is: ask Cowork what dataset/query you need (it'll
tell you from the catalog), download that one parquet file yourself, convert
it to CSV (the DuckDB CLI can do this in one line - see the comment in
SKILL.md), and upload the CSV into OneDrive or straight into the chat. From
there Cowork's built-in Excel skill handles it like any other spreadsheet.

`nibs_helper.py` includes a `download_and_load()` that tries to fetch
straight from Dropbox and read the parquet directly, in case Cowork's
execution sandbox turns out to have network access and a working parquet
reader (duckdb/pyarrow) - but I have no way to test Microsoft's environment
from here, so don't trust that path until you've watched it actually
succeed once. If it fails, that's expected - just use the CSV route.
