---
name: India Crop GHG (NIBS)
description: Analyze the NIBS India cropland greenhouse-gas dataset (github.com/npongo/NIBS) - ~300 parquet files covering CH4 (rice paddy methane), N2O (fertilizer-induced, rice/upland crops), nitrogen balance, and residue-burning CO2e emissions by Indian district, crop, and farm size. Use whenever I mention NIBS, India crop/cropland GHG data, Indian district or state agricultural emissions, rice paddy methane, N2O from Indian fertilizer use, residue/stubble burning emissions in India, or reference a dataset name from this catalog (vwM_district_*, vwG_national_*, ch4_bhatia_2013, n2o_ipcc_2019, apy, etc.).
---

This is the data behind Clark et al. 2026, Environ. Res. Lett. 21 064027,
"Potential for reducing greenhouse gas emissions from cropland in India:
where, which (crop), and who (farmers)." Data is CC BY-SA 4.0. The project
runs several independently published emission-factor models per gas in
parallel rather than trusting one - almost every question ("how much methane
does rice produce in Haryana") has more than one defensible answer depending
on which model backs it. Surface that rather than picking one silently: ask
which model I want, or offer the "_all_models" comparison view where one
exists.

IMPORTANT LIMITATION - read this before doing anything else: Cowork can't
access files on my local device, only OneDrive/SharePoint, and the actual
parquet files for this dataset are hosted on Dropbox, not OneDrive. Parquet
also isn't one of Cowork's officially supported attachment types (Excel/CSV,
Word, PDF, code, config, and a few others are). So you likely can't fetch or
directly open a .parquet file yourself. The reliable path is:

1. Use dataset_catalog.md and nib_urls.json (attached to this skill) to work
   out the exact dataset name and Dropbox URL for what I'm asking about.
2. Tell me the name and URL, and ask me to download it, convert it to CSV
   (e.g. with the DuckDB CLI: `duckdb -c "COPY (SELECT * FROM
   read_parquet('name.parquet')) TO 'name.csv' (HEADER, DELIMITER ',')"`, or
   open it in Excel via the DuckDB-Excel integration), and upload the CSV
   into OneDrive or straight into this chat.
3. Once I've uploaded the CSV, treat it like any other spreadsheet - use your
   Excel skill to filter, pivot, and summarize it.

If nibs_helper.py (also attached) turns out to run for you with real network
and duckdb/Python access, you can try the download-and-query path directly -
but I could not verify whether Cowork's execution environment allows that, so
don't assume it works. Confirm it actually ran before trusting any numbers it
returns, and fall back to the CSV path immediately if it errors.

WORKFLOW

1. Clarify scope: which gas/topic (CH4 / N2O-rice / N2O-upland / N-balance /
   residue burning), which geographic level (national or district), which
   breakdown (crop / farm size / irrigation / none), and which model (or a
   comparison across all of them). Just ask me directly if it's not obvious.

2. Read dataset_catalog.md for the naming grammar:
   <prefix><admin level><gas><aggregation variable><crop><name><model>
   Always prefer a dataset starting with vwA_, vwG_, or vwM_ over a raw base
   table. vwM_ is for map/district-level work (has a geog geometry column -
   drop it, it's not useful once exported to CSV), vwG_ is for chart-ready
   tabular summaries at any aggregation level, vwA_ is the general-purpose
   analysis-ready tier.

3. Use nib_urls.json to find the exact dataset name and its Dropbox URL -
   don't guess or pattern-match names, look them up.

4. Once I've uploaded real data, check the actual column headers before
   building any filter or pivot - column names are close-but-not-identical
   across the ~300 files in this catalog (e.g. some use total_Gg_co2e_map,
   others total_emissions_gg_co2e). Don't assume.

5. Almost every CO2e-converted view has a gwp_time_period column (100 or
   20-year AR6 GWP horizon) - filter it explicitly and tell me which horizon
   you used, since CH4 results especially shift a lot between them. Views
   that aren't CO2e-converted (n2o_n, raw ch4) don't need this filter.

6. Present results as a table, chart, or short Excel/Word summary depending
   on what I asked for. Cite Clark et al. 2026 in one line when summarizing
   findings, since this is data from a specific published study.

THINGS TO GET RIGHT
- Don't silently pick one model when several exist - say which one you used.
- Don't skip the gwp_time_period filter on CO2e-converted views.
- Crop names and farm-size categories are original census labels (e.g.
  'MARGINAL (BELOW 1.0)', 'Moong(Green Gram)') - clean up for presentation
  but don't assume they match what you'd expect; check dataset_catalog.md.
- The Shcherbak 2014 N2O national CO2e views exist under two spellings in
  the catalog (shcherbak_2014 and shcherback_2014) - both are real, separate
  files. Flag this rather than silently picking one.
- Never present a number you didn't actually compute from data I uploaded.
