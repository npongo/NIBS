"""
nibs_helper.py - NIBS India cropland GHG helper, best-effort adaptation for
Microsoft 365 Copilot Cowork.

Cowork can't access local files (only OneDrive/SharePoint), and .parquet
isn't in its list of officially supported attachment types - so I (the
assistant that prepared this file) could not verify whether this script will
actually run inside Cowork's execution environment, whether it has network
access to reach Dropbox, or which Python packages are pre-installed there.
Treat everything below as untested until you've confirmed it runs.

If it doesn't run at all, that's expected and fine - fall back to the
CSV-export workflow described in SKILL.md instead: ask the user to convert
the specific parquet file to CSV themselves (e.g. via the DuckDB CLI) and
upload that into OneDrive or the chat, then work with it as a normal
spreadsheet.

If it does run, usage is:

    from nibs_helper import NIBS
    nibs = NIBS(data_dir="/tmp/nibs_data")   # or wherever files land
    nibs.search("nikolaisen")
    nibs.get_url("vwM_district_ch4_summary_nikolaisen_2023")
    df = nibs.load_local("vwM_district_ch4_summary_nikolaisen_2023")  # if uploaded
    df = nibs.download_and_load("vwM_district_ch4_summary_nikolaisen_2023")  # if network works
"""
from __future__ import annotations

import glob
import json
import os
from typing import Optional

import pandas as pd

_HERE = os.path.dirname(__file__)
_CATALOG_PATH = os.path.join(_HERE, "nib_urls.json")

_ENGINE = None
try:
    import duckdb  # noqa: F401

    _ENGINE = "duckdb"
except ImportError:
    try:
        import pyarrow  # noqa: F401

        _ENGINE = "pyarrow"
    except ImportError:
        try:
            import fastparquet  # noqa: F401

            _ENGINE = "fastparquet"
        except ImportError:
            _ENGINE = None


class NIBS:
    def __init__(self, data_dir: str = "./nibs_data", catalog_path: str = _CATALOG_PATH):
        self.data_dir = data_dir
        if not os.path.exists(self.data_dir):
            try:
                os.makedirs(self.data_dir)
            except OSError:
                pass  # read-only environment - fine if we're only doing catalog lookups
        with open(catalog_path, encoding="utf-8") as f:
            self._urls: dict[str, str] = json.load(f)
        self._ci_keys = {k.lower(): k for k in self._urls}
        print(
            f"nibs_helper: parquet engine detected = {_ENGINE!r}. "
            "If this is None, load_local()/download_and_load() will fail - "
            "use the CSV-export fallback in SKILL.md instead."
        )

    # ------------------------------------------------------------------
    # catalog lookup - pure Python, no I/O, always works
    # ------------------------------------------------------------------
    def resolve_key(self, name: str) -> str:
        base = os.path.basename(name)
        if base.lower().endswith(".parquet"):
            base = base[: -len(".parquet")]
        if base.lower() in self._ci_keys:
            return self._ci_keys[base.lower()]
        raise ValueError(
            f"Dataset '{name}' not found in the NIBS catalog. Use NIBS.search('{base}') "
            "to find close matches."
        )

    def get_url(self, name: str) -> str:
        return self._urls[self.resolve_key(name)]

    def search(self, keyword: str) -> list[str]:
        kw = keyword.lower()
        return sorted(k for k in self._urls if kw in k.lower())

    def all_datasets(self) -> list[str]:
        return sorted(self._urls.keys())

    # ------------------------------------------------------------------
    # local file (already uploaded) - needs a parquet engine
    # ------------------------------------------------------------------
    def find_local(self, name: str) -> Optional[str]:
        key = self.resolve_key(name)
        candidates = glob.glob(os.path.join(self.data_dir, f"{key}*.parquet"))
        return candidates[0] if candidates else None

    def load_local(self, name: str) -> pd.DataFrame:
        local_path = self.find_local(name)
        if local_path is None:
            key = self.resolve_key(name)
            raise FileNotFoundError(
                f"'{key}.parquet' isn't in {self.data_dir}. Either it hasn't been "
                f"uploaded, or convert it to CSV first (see SKILL.md) - the URL is "
                f"{self._urls[key]}"
            )
        if _ENGINE is None:
            raise ImportError("No parquet engine available - use the CSV fallback instead.")
        return pd.read_parquet(local_path)

    # ------------------------------------------------------------------
    # network download - untested in this environment, try at your own risk
    # ------------------------------------------------------------------
    def download_and_load(self, name: str) -> pd.DataFrame:
        """Attempt to download straight from Dropbox and load it. Untested -
        Cowork's execution environment may not have outbound internet access.
        If this raises, don't retry silently - tell the user and fall back to
        asking them to upload a CSV export instead."""
        key = self.resolve_key(name)
        local_path = os.path.join(self.data_dir, f"{key}.parquet")
        if not os.path.exists(local_path):
            import requests

            url = self._urls[key]
            resp = requests.get(url, timeout=60)
            resp.raise_for_status()
            with open(local_path, "wb") as f:
                f.write(resp.content)
        return self.load_local(key)

    def describe_local(self, name: str) -> pd.DataFrame:
        df = self.load_local(name)
        return pd.DataFrame({"column": df.columns, "dtype": [str(t) for t in df.dtypes]})
